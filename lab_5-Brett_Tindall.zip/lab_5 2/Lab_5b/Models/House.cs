﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab_5b.Models
{
    //Class for the house model, conatins a houseId, owners first name, owners last name, house number, street name and the houses cost
    public class House
    {
        public int houseID { get; set; }

        public string ownerFirstName { get; set; }

        public string ownerLastName { get; set; }

        public int houseNo { get; set; }

        public string streetName { get; set; }

        public double cost { get; set; }

    }
}
