﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab_5b.Models
{
    //A class for the customer class that contains an id, first name, last name and a foreign key for agentId
    public class Customer
    {
        public int id { get; set; }

        public string firstName { get; set; }

        public string lastName { get; set; }

        public int agentID { get; set; }

        public Agent Agent { get; set; }
    }
}
