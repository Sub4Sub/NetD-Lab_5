using System;

namespace Lab_5b.Models
{
    //Default error view, didnt remove just in case
    public class ErrorViewModel
    {
        public string RequestId { get; set; }

        public bool ShowRequestId => !string.IsNullOrEmpty(RequestId);
    }
}
