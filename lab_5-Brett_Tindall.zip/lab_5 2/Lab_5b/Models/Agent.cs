﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Lab_5b.Models
{
    //Class for the agent model, contains a first name, last name and Id
    public class Agent
    {
        public int agentID { get; set; }

        public string firstName { get; set; }

        public string lastName { get; set; }
    }
}
