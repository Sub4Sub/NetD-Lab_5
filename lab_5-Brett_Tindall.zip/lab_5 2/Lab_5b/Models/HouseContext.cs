﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.EntityFrameworkCore;

namespace Lab_5b.Models
{
    //Context class for creating db tables
    public class HouseContext : DbContext
    {
        //Defult constructor for HouseContext
        public HouseContext(DbContextOptions<HouseContext> options) : base(options)
        {



        }

        //Adding a list of objects for each table that will be created, which are the houses, agents and customer objects
        public DbSet<House> Houses { get; set; }
        public DbSet<Agent> Agents { get; set; }
        public DbSet<Customer> Customers { get; set; }

    }
}
